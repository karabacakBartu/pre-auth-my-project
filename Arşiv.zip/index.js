
const connectToDatabase =require("./connection");


exports.handler = async(event,context,callback) => {
    const {database}= await connectToDatabase.getConnection()

    const codeCollection = database.collection("codes")

    const result=await codeCollection.findOne();


    if(result ){
        const dbCode=result.code;
        console.log("dbCodee", dbCode)
        const awsCode=event.request.validationData.code;
        console.log("awsCodee", awsCode)
        if(dbCode===awsCode){
            callback(null,event);
        }
    }
    throw new Error()

};
// this.handler()